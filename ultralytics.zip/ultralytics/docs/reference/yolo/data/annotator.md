# auto_annotate
---
:::ultralytics.yolo.data.annotator.auto_annotate
<br><br>
