# DetectionValidator
---
:::ultralytics.yolo.v8.detect.val.DetectionValidator
<br><br>

# val
---
:::ultralytics.yolo.v8.detect.val.val
<br><br>
