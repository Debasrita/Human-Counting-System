# ClassificationTrainer
---
:::ultralytics.yolo.v8.classify.train.ClassificationTrainer
<br><br>

# train
---
:::ultralytics.yolo.v8.classify.train.train
<br><br>
