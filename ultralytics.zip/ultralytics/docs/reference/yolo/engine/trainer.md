# BaseTrainer
---
:::ultralytics.yolo.engine.trainer.BaseTrainer
<br><br>

# check_amp
---
:::ultralytics.yolo.engine.trainer.check_amp
<br><br>
